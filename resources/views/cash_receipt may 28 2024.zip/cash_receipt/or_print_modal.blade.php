<style type="text/css">
    .modal-conf {
        max-width:80% !important;
        min-width:80% !important;
    }
</style>
<div class="modal modalfade" id="modal_print" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-conf" role="document">
        <div class="modal-content">
            <div class="modal-body" style="max-height: calc(100vh - 170px);overflow-y: auto;overflow-x: auto;"> 
                 <iframe id="print_frame_or"  style="border:0;height:900px;width: 100%"> </iframe>
            </div>
        </div>
    </div>
</div>